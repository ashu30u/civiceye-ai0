const express = require("express");
const { Village, Ward, Department, Complaint } = require("../models/models");
const { protect } = require("../middleware/auth");
const { SEVERITY_RANK } = require("../services/ai/aiService");

const router = express.Router();

// GET /api/villages
router.get("/", protect, async (req, res) => {
  const villages = await Village.find();
  res.json(villages);
});

// GET /api/villages/:id
router.get("/:id", protect, async (req, res) => {
  const village = await Village.findById(req.params.id);
  if (!village) return res.status(404).json({ message: "Village not found" });
  const wards = await Ward.find({ village: village._id });
  res.json({ village, wards });
});

// GET /api/villages/:id/analytics
router.get("/:id/analytics", protect, async (req, res) => {
  const complaints = await Complaint.find({ village: req.params.id, isDeleted: false }).populate("ward", "name");

  const total = complaints.length;
  const resolved = complaints.filter((c) => c.status === "RESOLVED").length;
  const critical = complaints.filter((c) => c.severity === "CRITICAL" || c.severity === "HIGH").length;

  const byCategory = {};
  const bySeverity = { LOW: 0, MEDIUM: 0, HIGH: 0, CRITICAL: 0 };
  const byWard = {};

  complaints.forEach((c) => {
    byCategory[c.category] = (byCategory[c.category] || 0) + 1;
    bySeverity[c.severity] = (bySeverity[c.severity] || 0) + 1;
    const wName = c.ward?.name || "Unknown";
    byWard[wName] = (byWard[wName] || 0) + 1;
  });

  res.json({
    total,
    resolved,
    critical,
    resolutionRate: total ? Math.round((resolved / total) * 100) : 0,
    byCategory,
    bySeverity,
    byWard,
  });
});

// GET /api/departments
router.get("/meta/departments", protect, async (req, res) => {
  const departments = await Department.find();
  res.json(departments);
});

module.exports = router;
